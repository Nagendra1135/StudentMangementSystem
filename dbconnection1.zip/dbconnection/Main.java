package com.dbconnection;

//Main.java
import java.util.Scanner;

public class Main {
 public static void main(String[] args) {
     StudentDAO dao = new StudentDAO();
     Scanner sc = new Scanner(System.in);
     int choice;

     do {
         System.out.println("\n====== Student Management System ======");
         System.out.println("1. Add Student");
         System.out.println("2. View All Students");
         System.out.println("3. Update Student");
         System.out.println("4. Delete Student");
         System.out.println("0. Exit");
         System.out.print("Enter your choice: ");
         choice = sc.nextInt();

         switch (choice) {
             case 1:
                 System.out.print("Enter name: ");
                 String name = sc.next();
                 System.out.print("Enter age: ");
                 int age = sc.nextInt();
                 System.out.print("Enter email: ");
                 String email = sc.next();
                 dao.addStudent(name, age, email);
                 break;
             case 2:
                 dao.viewAllStudents();
                 break;
             case 3:
                 System.out.print("Enter ID to update: ");
                 int idUpdate = sc.nextInt();
                 System.out.print("Enter new name: ");
                 String nameU = sc.next();
                 System.out.print("Enter new age: ");
                 int ageU = sc.nextInt();
                 System.out.print("Enter new email: ");
                 String emailU = sc.next();
                 dao.updateStudent(idUpdate, nameU, ageU, emailU);
                 break;
             case 4:
                 System.out.print("Enter ID to delete: ");
                 int idDelete = sc.nextInt();
                 dao.deleteStudent(idDelete);
                 break;
             case 0:
                 System.out.println("👋 Exiting...");
                 break;
             default:
                 System.out.println("❌ Invalid choice.");
         }
     } while (choice != 0);

     sc.close();
 }
}

