package com.dbconnection;

//StudentDAO.java
import java.sql.*;
import java.util.*;

public class StudentDAO {
 public void addStudent(String name, int age, String email) {
     try (Connection conn = DBConnection.getConnection()) {
         String sql = "INSERT INTO students (name, age, email) VALUES (?, ?, ?)";
         PreparedStatement stmt = conn.prepareStatement(sql);
         stmt.setString(1, name);
         stmt.setInt(2, age);
         stmt.setString(3, email);
         stmt.executeUpdate();
         System.out.println("✅ Student added successfully.");
     } catch (Exception e) {
         e.printStackTrace();
     }
 }

 public void viewAllStudents() {
     try (Connection conn = DBConnection.getConnection()) {
         String sql = "SELECT * FROM students";
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql);

         while (rs.next()) {
             System.out.println(
                 rs.getInt("id") + " | " +
                 rs.getString("name") + " | " +
                 rs.getInt("age") + " | " +
                 rs.getString("email"));
         }
     } catch (Exception e) {
         e.printStackTrace();
     }
 }

 public void updateStudent(int id, String name, int age, String email) {
     try (Connection conn = DBConnection.getConnection()) {
         String sql = "UPDATE students SET name=?, age=?, email=? WHERE id=?";
         PreparedStatement stmt = conn.prepareStatement(sql);
         stmt.setString(1, name);
         stmt.setInt(2, age);
         stmt.setString(3, email);
         stmt.setInt(4, id);
         int rows = stmt.executeUpdate();
         if (rows > 0)
             System.out.println("✅ Student updated.");
         else
             System.out.println("⚠️ No student found with that ID.");
     } catch (Exception e) {
         e.printStackTrace();
     }
 }

 public void deleteStudent(int id) {
     try (Connection conn = DBConnection.getConnection()) {
         String sql = "DELETE FROM students WHERE id=?";
         PreparedStatement stmt = conn.prepareStatement(sql);
         stmt.setInt(1, id);
         int rows = stmt.executeUpdate();
         if (rows > 0)
             System.out.println("🗑️ Student deleted.");
         else
             System.out.println("⚠️ No student found with that ID.");
     } catch (Exception e) {
         e.printStackTrace();
     }
 }
}
