package com.dbconnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=student_db;encrypt=true;trustServerCertificate=true";
	private static final String USER = "sa"; // or your SQL Server username
	private static final String PASSWORD = "N@gendr@123"; // replace with your actual password


    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void main(String[] args) {
        try {
            Connection conn = getConnection();
            System.out.println("✅ Connected to SQL Server!");
            conn.close();
        } catch (SQLException e) {
            System.out.println("❌ Connection failed!");
            e.printStackTrace();
        }
    }
}

